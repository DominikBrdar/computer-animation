﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirectKinematic : MonoBehaviour
{

    public GameObject S_Axis_1;
    public GameObject L_Axis_2;
    public GameObject U_Axis_3;
    public GameObject U_Axis_3_t; // translacijski zglob
    public GameObject R_Axis_4;
    public GameObject B_Axis_5;

    public Dictionary<GameObject, bool> joints = new Dictionary<GameObject, bool>();

    

    public float rotSpeed = 0.1f;
    public float trSpeed = 0.1f;

    public float rot = 0;
    public float tr = 0;

    private int s;

    public bool check;

    // TODO: 
    // za predefinirane kutove u zglobovima
    public Dictionary<GameObject, float> jointAngles = new Dictionary<GameObject, float>();

    public void animateForInput(Dictionary<GameObject, float> jointAngles)
    {
        foreach (GameObject j in jointAngles.Keys){
            j.GetComponent<ControlJoint1DOF>().rotate(jointAngles[j]);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        joints.Add(S_Axis_1, false);
        joints.Add(L_Axis_2, false);
        joints.Add(U_Axis_3, false);
        joints.Add(U_Axis_3_t, false);
        joints.Add(R_Axis_4, false);
        joints.Add(B_Axis_5, false);
    }

    // Update is called once per frame
    void Update()
    {
        // return to neutral
        if (Input.GetKeyDown(KeyCode.S) || s > 0)
        {
            s = 5;

            if (S_Axis_1.transform.localEulerAngles.y > 1 &&
                S_Axis_1.transform.localEulerAngles.y < 180)
                S_Axis_1.transform.Rotate(0f, -rotSpeed, 0f);
            else if (S_Axis_1.transform.localEulerAngles.y > 1 && 
                     S_Axis_1.transform.localEulerAngles.y < 359)
                S_Axis_1.transform.Rotate(0f, rotSpeed, 0f);
            else s--;
            
            if (L_Axis_2.transform.localEulerAngles.z > 1 &&
                L_Axis_2.transform.localEulerAngles.z < 180)
            {
                L_Axis_2.transform.Rotate(0f, 0f, -rotSpeed);
            }
            else if (L_Axis_2.transform.localEulerAngles.z > 1 && 
                     L_Axis_2.transform.localEulerAngles.z < 359)
            {
                L_Axis_2.transform.Rotate(0f, 0f, rotSpeed);
            }
            else s--;

            if (U_Axis_3.transform.localEulerAngles.z > 1 &&
                U_Axis_3.transform.localEulerAngles.z < 180)
            {
                U_Axis_3.transform.Rotate(0f, 0f, -rotSpeed);
            }
            else if (U_Axis_3.transform.localEulerAngles.z > 1 && 
                     L_Axis_2.transform.localEulerAngles.z < 359)
            {
                U_Axis_3.transform.Rotate(0f, 0f, rotSpeed);
            }
            else s--;

            if (R_Axis_4.transform.localEulerAngles.y > 1 &&
                R_Axis_4.transform.localEulerAngles.y < 180)
            {
                R_Axis_4.transform.Rotate(0f, -rotSpeed, 0f);
            }
            else if (R_Axis_4.transform.localEulerAngles.y > 1 && 
                     R_Axis_4.transform.localEulerAngles.y < 359)
            {
                R_Axis_4.transform.Rotate(0f, rotSpeed, 0f);
            }
            else s--;

            if (B_Axis_5.transform.localEulerAngles.z > 1 &&
                B_Axis_5.transform.localEulerAngles.z < 180)
            {
                B_Axis_5.transform.Rotate(0f, 0f, -rotSpeed);
            }
            else if (B_Axis_5.transform.localEulerAngles.z > 1 && 
                     B_Axis_5.transform.localEulerAngles.z < 359)
            {
                B_Axis_5.transform.Rotate(0f, 0f, rotSpeed);
            }
            else s--;

            return;
        }

        if (Input.GetKeyUp(KeyCode.RightArrow) || Input.GetKeyUp(KeyCode.LeftArrow))
            rot = 0;
        if (Input.GetKeyUp(KeyCode.UpArrow) || Input.GetKeyUp(KeyCode.DownArrow))
            tr = 0;

        if (Input.GetKeyDown(KeyCode.RightArrow))
            rot = rotSpeed;
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
            rot = -rotSpeed;

        if (Input.GetKeyDown(KeyCode.UpArrow))
            tr = trSpeed;
        else if (Input.GetKeyDown(KeyCode.DownArrow))
            tr = -trSpeed;

        if (Input.GetKey(KeyCode.Alpha1)) {
            S_Axis_1.transform.Rotate(0f, rot, 0f);
            if (S_Axis_1.GetComponent<ControlJoint1DOF>().blocked)
            {
                S_Axis_1.transform.Rotate(0f, -6*rot, 0f);
                joints[S_Axis_1] = false;
                S_Axis_1.GetComponent<ControlJoint1DOF>().blocked = false;
                Debug.Log("colliding");
            }
                
        }

        if (Input.GetKey(KeyCode.Alpha2))
        {
            L_Axis_2.transform.Rotate(0f, 0f, rot);
            if (L_Axis_2.transform.localEulerAngles.z < 330 &&
                L_Axis_2.transform.localEulerAngles.z > 160)
            {
                L_Axis_2.transform.Rotate(0f, 0f, -rot);
            }
        }
            
        if (Input.GetKey(KeyCode.Alpha3))
        {
            U_Axis_3.transform.Rotate(0f, 0f, rot);
            U_Axis_3_t.transform.Translate(0f, tr, 0f);
            if (U_Axis_3.transform.localEulerAngles.z < 240 &&
                U_Axis_3.transform.localEulerAngles.z > 155)
            {
                U_Axis_3.transform.Rotate(0f, 0f, -rot);
            }
            if (U_Axis_3_t.transform.localPosition.y <= 0.52 ||
                U_Axis_3_t.transform.localPosition.y >= 0.9)
            {
                U_Axis_3_t.transform.Translate(0f, -tr, 0f);
            }   
        }

        if (Input.GetKey(KeyCode.Alpha4))
        {
            R_Axis_4.transform.Rotate(0f, rot, 0f);
        }

        if (Input.GetKey(KeyCode.Alpha5))
        { 
            B_Axis_5.transform.Rotate(0f, 0f, rot);
            if (B_Axis_5.transform.localEulerAngles.z < 235 &&
                B_Axis_5.transform.localEulerAngles.z > 125)
            {
                B_Axis_5.transform.Rotate(0f, 0f, -rot);
            }
        }


        /*
        if (Input.GetKeyDown(KeyCode.Alpha1)) joints[S_Axis_1] = true;
        if (Input.GetKeyUp(KeyCode.Alpha1)) joints[S_Axis_1] = false;

        if (Input.GetKeyDown(KeyCode.Alpha2)) joints[L_Axis_2] = true;
        if (Input.GetKeyUp(KeyCode.Alpha2)) joints[L_Axis_2] = false;

        if (Input.GetKeyDown(KeyCode.Alpha3)) joints[U_Axis_3] = true;
        if (Input.GetKeyUp(KeyCode.Alpha3)) joints[U_Axis_3] = false;

        if (Input.GetKeyDown(KeyCode.Alpha4)) joints[R_Axis_4] = true;
        if (Input.GetKeyUp(KeyCode.Alpha4)) joints[R_Axis_4] = false;

        if (Input.GetKeyDown(KeyCode.Alpha5)) joints[B_Axis_5] = true;
        if (Input.GetKeyUp(KeyCode.Alpha5)) joints[B_Axis_5] = false;
        */
    }
}
