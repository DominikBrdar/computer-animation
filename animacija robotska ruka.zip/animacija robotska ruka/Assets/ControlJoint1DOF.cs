﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlJoint1DOF: MonoBehaviour
{
    // needs reference to main control unit
    public DirectKinematic dk;

    public float maxAnglePos;
    public float maxAngleNeg;
    public float maxLoad;
    public float speed;

    // only one should be true
    public bool x;
    public bool y;
    public bool z;

    // only one should be true
    public bool rotation;
    public bool translation;

    public bool blocked;
    public bool active;
    private float angle;
    private float desiredAngle = 404;

    /// <summary>
    /// moves (rotates) the joint for given angle
    /// </summary>
    /// <returns>
    /// 0 if rotation was performed
    /// -1 if joint is blocked because of max load constraint
    /// -2 if joint is blocked because of min or max angle constraint
    /// </returns>
    public int rotate(float forAngle)
    {
        if (forAngle != 0f) desiredAngle = 500f;
        if (Mathf.Abs(angle - desiredAngle) < 0.5 || desiredAngle == 404f)
        {
            return 0;
        }
        else if (desiredAngle > 360f)
        {
            desiredAngle = (angle + forAngle) % 360f;
        }
        transform.Rotate(x ? dk.rot * speed : 0f, y ? dk.rot * speed : 0f, z ? dk.rot * speed : 0f);
        if (x) angle = transform.localEulerAngles.x;
        if (y) angle = transform.localEulerAngles.y;
        if (z) angle = transform.localEulerAngles.z;

        // if fail
        if (angle < 360 + maxAngleNeg 
            && angle > maxAnglePos
            || blocked)
        {
            transform.Rotate(x ? -dk.rot * speed : 0f, y ? -dk.rot * speed : 0f, z ? -dk.rot * speed : 0f);
            desiredAngle = 404f;
            if (blocked)
                return -1; 
            else
                return -2;
        }
        else
        {
            desiredAngle = 404f;
            return 0; // success
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        rotate(0f);
    }

    // sensors for blocking -> blocks joint if load is too heavy (if it bumps into too heavy object)
    private void OnTriggerStay(Collider other)
    {
        // TODO: block joint which causes bumping 
        // trenutno samo za 1. zglob

        if (Input.GetKey(KeyCode.Alpha1)
            && other.attachedRigidbody.mass > maxLoad)
        {
            dk.joints[gameObject] = true;
            blocked = true;
        }
    }
}
